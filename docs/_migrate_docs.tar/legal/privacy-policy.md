---
title: Privacy Policy
---

# Privacy Policy

API logs and telemetry are used for debugging and deleted after 30 days. No personal data is sold.

> Last updated: 2025-08-20

Return: [Legal Index](README.md)
