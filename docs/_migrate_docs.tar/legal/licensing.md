---
title: Licensing
---

# Licensing

Code is released under the Apache-2.0 license. Modules may carry additional terms; see individual files.

> Last updated: 2025-08-20

Return: [Legal Index](README.md)
