---
title: Testnet Terms
---

# Testnet Terms

Participation is at your own risk. Tokens have no monetary value. Do not use for production. Rate limits apply.

> Last updated: 2025-08-20

Return: [Legal Index](README.md)
