// This file is deprecated. Root-level docusaurus.config.js is authoritative.
// Kept to avoid broken references; exports root config.
import config from '../docusaurus.config.js';
export default config;
