---
title: "Python Quickstart"
---

# Python Quickstart

Use the Python SDK.

> Last updated: 2025-08-20

```python
from dytallix import Client
c = Client('https://rpc.testnet.dytallix.example')
print(c.status())
```

Next: [Go Quickstart](go-quickstart.md)
