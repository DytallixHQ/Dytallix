Placeholder for image assets (logo.png, diagrams, social-card.png)
Add actual binary images outside of automated text patch.
